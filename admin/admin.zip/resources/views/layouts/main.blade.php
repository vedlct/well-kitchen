<!doctype html>
<html lang="en">

@include('layouts.partials.header')
@include('layouts.partials.sidebar')
    @yield('main.content')
@include('layouts.partials.footer')

</html>
