<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockRecord extends Model
{
    protected $table ='stock_record';
    protected $primaryKey='stock_recordId';
}
