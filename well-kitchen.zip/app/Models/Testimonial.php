<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model
{
    //
//    protected $table ='feedback';
//    protected $primaryKey='feedbackId';
//    public $timestamps = false;
    protected $table ='testimonial';
    protected $primaryKey='testimonial_id';
    public $timestamps = false;

   
}
