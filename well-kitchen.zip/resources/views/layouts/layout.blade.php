
@include('layouts.partials.header')

@yield('container')

@include('layouts.partials.footer')